<!-- Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al. -->
<!-- SPDX-License-Identifier: curl -->
# BUGS
If you experience any problems with curl, submit an issue in the project's bug
tracker on GitHub: https://github.com/curl/curl/issues
